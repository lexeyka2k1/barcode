package ru.rounb.springsBarcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsBarcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
