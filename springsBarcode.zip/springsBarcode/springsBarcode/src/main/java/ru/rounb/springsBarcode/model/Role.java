package ru.rounb.springsBarcode.model;

public enum Role {
    ADMIN,
    USER
}
